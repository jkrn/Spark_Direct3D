#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <tuple>
#include <algorithm>

using namespace std;

// --- Types ---

typedef unsigned int uin;
typedef float FLOAT;
typedef unsigned char BYTE;

typedef struct COLOR {
    float r;
    float g;
    float b;
    float a;
    COLOR(float r, float g, float b, float a) : r(r), g(g), b(b), a(a) {}
    COLOR() : COLOR(0.0f, 0.0f, 0.0f, 1.0f) {}
} COLOR;

struct VERTEX {
    // POSITION - 0 BYTES
    FLOAT X;
    FLOAT Y;
    FLOAT Z;
    // NORMAL - 12 BYTES
    FLOAT NX;
    FLOAT NY;
    FLOAT NZ;
    // TANGENT - 24 BYTES
    FLOAT TX;
    FLOAT TY;
    FLOAT TZ;
    // BINORMAL - 36 BYTES
    FLOAT BX;
    FLOAT BY;
    FLOAT BZ;
    // COLOR - 48 BYTES
    COLOR Color;
    // TEXCOORD - 64 BYTES
    FLOAT U;
    FLOAT V;
    // TOTAL - 72 BYTES
};

struct BINMESH {
    unsigned int numVertices = 0;
    unsigned int numIndices = 0;
    VERTEX* vertices = NULL;
    unsigned int* indices = NULL;
};

class Pos {
public:
    double x;
    double y;
    double z;
    Pos(double x, double y, double z) : x(x), y(y), z(z) {}
};

class Tex {
public:
    double u;
    double v;
    Tex(double u, double v) : u(u), v(v) {}
};

class Normal {
public:
    double nx;
    double ny;
    double nz;
    Normal(double nx, double ny, double nz) : nx(nx), ny(ny), nz(nz) {}
};

class VertexIndexSet {
public:
    uin pos_ind;
    uin tex_ind;
    uin nrm_ind;
    VertexIndexSet() : VertexIndexSet(0, 0, 0) {}
    VertexIndexSet(uin pos_ind, uin tex_ind, uin nrm_ind) : pos_ind(pos_ind), tex_ind(tex_ind), nrm_ind(nrm_ind) {}
};

class Facet {
public:
    VertexIndexSet sets[3];
    Facet(VertexIndexSet set0, VertexIndexSet set1, VertexIndexSet set2) {
        sets[0] = set0;
        sets[1] = set1;
        sets[2] = set2;
    }
};

class Vertex {
public:
    Pos pos;
    Tex tex;
    Normal normal;
    Vertex(double x, double y, double z, double u, double v, double nx, double ny, double nz) : pos(Pos(x, y, z)), tex(Tex(u, v)), normal(Normal(nx, ny, nz)) {}
};

class Mesh {
public:
    // OBJ File structure
    uin numPos;
    uin numTexs;
    uin numNrms;
    uin numFacets;
    uin numIndices;
    std::vector<Pos> pos_vec;
    std::vector<Tex> tex_vec;
    std::vector<Normal> nrm_vec;
    std::vector<Facet> facet_vec;
    // HPP File structure
    uin num_used_vertices;
    uin num_used_indices;
    uin num_used_triangles;
    std::vector<VertexIndexSet> used_vertices_indices;
    std::vector<Vertex> used_vertices;
    std::vector<std::tuple<uin, uin, uin>> used_indices;
    // Functions
    Mesh() : numPos(0), numTexs(0), numNrms(0), numFacets(0), numIndices(0), num_used_vertices(0), num_used_indices(0), num_used_triangles(0) {}
    void add_vertex_to_used_vertices(VertexIndexSet vertexIndexSet) {
        // Check if VertexIndexSet already exists
        for (uin i = 0; i < num_used_vertices; i++) {
            // Get IndexSet
            VertexIndexSet& curr_vertexIndexSet = used_vertices_indices.at(i);
            if (curr_vertexIndexSet.pos_ind == vertexIndexSet.pos_ind &&
                curr_vertexIndexSet.tex_ind == vertexIndexSet.tex_ind &&
                curr_vertexIndexSet.nrm_ind == vertexIndexSet.nrm_ind) {
                return;
            }
        }
        // Add new VertexIndexSet
        used_vertices_indices.push_back(vertexIndexSet);
        num_used_vertices = (uin)used_vertices_indices.size();
    }
    void convert_vertices_indices_to_vertices() {
        for (uin i = 0; i < num_used_vertices; i++) {
            // Get IndexSet
            VertexIndexSet& curr_vertexIndexSet = used_vertices_indices.at(i);
            // Get Pos, Tex and Normal values
            Pos& pos = pos_vec.at(curr_vertexIndexSet.pos_ind);
            Tex& tex = tex_vec.at(curr_vertexIndexSet.tex_ind);
            Normal& normal = nrm_vec.at(curr_vertexIndexSet.nrm_ind);
            // Create Vertex
            used_vertices.push_back(Vertex(pos.x, pos.y, pos.z, tex.u, tex.v, normal.nx, normal.ny, normal.nz));
        }
    }
    uin get_used_index_from_vertexIndexSet(VertexIndexSet& vertexIndexSet) {
        uin used_index = 0;
        for (uin i = 0; i < num_used_vertices; i++) {
            // Get IndexSet
            VertexIndexSet& curr_vertexIndexSet = used_vertices_indices.at(i);
            if (curr_vertexIndexSet.pos_ind == vertexIndexSet.pos_ind &&
                curr_vertexIndexSet.tex_ind == vertexIndexSet.tex_ind &&
                curr_vertexIndexSet.nrm_ind == vertexIndexSet.nrm_ind) {
                used_index = i;
                break;
            }
        }
        return used_index;
    }
};

// --- global variables ---

string g_obj_file_name;
string g_binmesh_file_name;
Mesh g_mesh;

// --- parameters ---

void printhelp() {
    cout << "Usage:" << endl;
    cout << "./convert_obj_to_binmesh [PARAMETERS]" << endl;
    cout << "-help: prints this text" << endl;
    cout << "-o [FILE NAME]: OBJ File Name" << endl;
    cout << "-b [FILE NAME]: BINMESH File Name" << endl;
}

bool processInputParamters(int argc, char* argv[]) {
    bool oMissing = true, bMissing = true;
    string o, b;
    for (int currArg = 1; currArg < argc - 1; currArg++) {
        string str(argv[currArg]);
        if (!str.compare("-help")) { printhelp(); return false; }
        else if (!str.compare("-o")) { o = string(argv[currArg + 1]); oMissing = false; }
        else if (!str.compare("-b")) { b = string(argv[currArg + 1]); bMissing = false; }
    }
    if (oMissing || bMissing) {
        if (oMissing) { cout << "(!) OBJ File Missing" << endl; }
        if (bMissing) { cout << "(!) BINMESH File Missing" << endl; }
        printhelp();
        return false;
    }
    g_obj_file_name = o;
    g_binmesh_file_name = b;
    cout << "OBJ File: " << g_obj_file_name << endl;
    cout << "BINMESH File: " << g_binmesh_file_name << endl;
    return true;
}

// --- File IO ---

void splitString(const std::string& str, std::vector<std::string>& vec, char delim) {
    std::stringstream ss(str);
    std::string token;
    while (std::getline(ss, token, delim)) { vec.push_back(token); }
}

void read_obj_file() {
    // Open File
    ifstream f(g_obj_file_name);
    // Read lines
    string currLine;
    while (std::getline(f, currLine)) {
        std::vector<std::string> entries;
        splitString(currLine, entries, ' ');
        // Positions
        if (entries.size() == 4 && (entries.at(0).compare("v") == 0)) {
            double x = (double)stod(entries.at(1));
            double y = (double)stod(entries.at(2));
            double z = (double)stod(entries.at(3));
            g_mesh.pos_vec.push_back(Pos(-x, z, y));
        }
        // Texs
        else if (entries.size() == 3 && (entries.at(0).compare("vt") == 0)) {
            double u = (double)stod(entries.at(1));
            double v = (double)stod(entries.at(2));
            g_mesh.tex_vec.push_back(Tex(u, 1.0 - v));
        }
        // Normals
        else if (entries.size() == 4 && (entries.at(0).compare("vn") == 0)) {
            double nx = (double)stod(entries.at(1));
            double ny = (double)stod(entries.at(2));
            double nz = (double)stod(entries.at(3));
            g_mesh.nrm_vec.push_back(Normal(-nx, +nz, +ny));
        }
        // Facets
        else if (entries.size() == 4 && (entries.at(0).compare("f") == 0)) {
            std::vector<std::string> elems0, elems1, elems2;
            splitString(entries.at(1), elems0, '/');
            splitString(entries.at(2), elems1, '/');
            splitString(entries.at(3), elems2, '/');
            uin pos_ind0 = (uin)stoi(elems0.at(0));
            uin tex_ind0 = (uin)stoi(elems0.at(1));
            uin nrm_ind0 = (uin)stoi(elems0.at(2));
            uin pos_ind1 = (uin)stoi(elems1.at(0));
            uin tex_ind1 = (uin)stoi(elems1.at(1));
            uin nrm_ind1 = (uin)stoi(elems1.at(2));
            uin pos_ind2 = (uin)stoi(elems2.at(0));
            uin tex_ind2 = (uin)stoi(elems2.at(1));
            uin nrm_ind2 = (uin)stoi(elems2.at(2));
            g_mesh.facet_vec.push_back(Facet(
                VertexIndexSet(pos_ind0 - 1, tex_ind0 - 1, nrm_ind0 - 1),
                VertexIndexSet(pos_ind1 - 1, tex_ind1 - 1, nrm_ind1 - 1),
                VertexIndexSet(pos_ind2 - 1, tex_ind2 - 1, nrm_ind2 - 1)));
        }
    }
    // Set sizes
    g_mesh.numPos = (uin)g_mesh.pos_vec.size();
    g_mesh.numTexs = (uin)g_mesh.tex_vec.size();
    g_mesh.numNrms = (uin)g_mesh.nrm_vec.size();
    g_mesh.numFacets = (uin)g_mesh.facet_vec.size();
    g_mesh.numIndices = 3 * g_mesh.numFacets;
    cout << "Positions: " << g_mesh.numPos << endl;
    cout << "Texs: " << g_mesh.numTexs << endl;
    cout << "Normals: " << g_mesh.numNrms << endl;
    cout << "Facets: " << g_mesh.numFacets << endl;
    cout << "Indices: " << g_mesh.numIndices << endl;
    // Used Vertices
    for (uin facet_ind = 0; facet_ind < g_mesh.numFacets; facet_ind++) {
        Facet& facet = g_mesh.facet_vec.at(facet_ind);
        g_mesh.add_vertex_to_used_vertices(facet.sets[0]);
        g_mesh.add_vertex_to_used_vertices(facet.sets[1]);
        g_mesh.add_vertex_to_used_vertices(facet.sets[2]);
    }
    g_mesh.convert_vertices_indices_to_vertices();
    // Used Indices
    for (uin facet_ind = 0; facet_ind < g_mesh.numFacets; facet_ind++) {
        Facet& facet = g_mesh.facet_vec.at(facet_ind);
        uin used_index_0 = g_mesh.get_used_index_from_vertexIndexSet(facet.sets[0]);
        uin used_index_1 = g_mesh.get_used_index_from_vertexIndexSet(facet.sets[1]);
        uin used_index_2 = g_mesh.get_used_index_from_vertexIndexSet(facet.sets[2]);
        g_mesh.used_indices.push_back(std::make_tuple(used_index_0, used_index_1, used_index_2));
    }
    g_mesh.num_used_triangles = (uin)g_mesh.used_indices.size();
    g_mesh.num_used_indices = g_mesh.num_used_triangles * 3;
    // Used Sizes
    cout << "Used Vertices: " << g_mesh.num_used_vertices << endl;
    cout << "Used Indices: " << g_mesh.num_used_indices << endl;
    cout << "Used Triangles: " << g_mesh.num_used_triangles << endl;
}

void write_binmesh_file() {
    // Sizes
    uint32_t numIndices = g_mesh.num_used_indices;
    uint32_t numVertices = g_mesh.num_used_vertices;
    // Allocate Array
    BYTE* byte_stream = new BYTE[ ( (2 + numIndices) * sizeof(uint32_t) ) + ( (numVertices) * sizeof(VERTEX) ) ];
    // Set sizes_indices
    uint32_t* d0 = (uint32_t*) ( (BYTE*) ( byte_stream + 0) );
    VERTEX* d1 = (VERTEX*) ( (BYTE*) ( byte_stream + (2 + numIndices) * sizeof(uint32_t) ) );
    d0[0] = numIndices;
    d0[1] = numVertices;
    for (uin i = 0; i < g_mesh.num_used_triangles; i++) {
        d0[(i * 3 + 0) + 2] = (uint32_t)(std::get<0>(g_mesh.used_indices.at(i)));
        d0[(i * 3 + 1) + 2] = (uint32_t)(std::get<2>(g_mesh.used_indices.at(i)));
        d0[(i * 3 + 2) + 2] = (uint32_t)(std::get<1>(g_mesh.used_indices.at(i)));
    }
    // Set vertices
    for (uin i = 0; i < g_mesh.num_used_vertices; i++) {
        d1[i] = { (float)g_mesh.used_vertices.at(i).pos.x , (float)g_mesh.used_vertices.at(i).pos.y , (float)g_mesh.used_vertices.at(i).pos.z, (float)g_mesh.used_vertices.at(i).normal.nx , (float)g_mesh.used_vertices.at(i).normal.ny, (float)g_mesh.used_vertices.at(i).normal.nz,  0.0f,0.0f,0.0f  ,  0.0f,0.0f,0.0f  ,  {1.0f,1.0f,1.0f,1.0f}  ,  (float)g_mesh.used_vertices.at(i).tex.u, (float)g_mesh.used_vertices.at(i).tex.v };
    }
    // Write File
    ofstream f(g_binmesh_file_name, ios::binary);
    f.write( (char*)byte_stream, ((2 + numIndices) * sizeof(uint32_t)) + ((numVertices) * sizeof(VERTEX)));
    // Free Array
    delete[] byte_stream;
}

// --- Main ---

int main(int argc, char* argv[]) {
    // Process Input Parameters
    if (!processInputParamters(argc, argv)) { return EXIT_FAILURE; }
    // read OBJ File
    read_obj_file();
    // write BINMESH File
    write_binmesh_file();
    return EXIT_SUCCESS;
}