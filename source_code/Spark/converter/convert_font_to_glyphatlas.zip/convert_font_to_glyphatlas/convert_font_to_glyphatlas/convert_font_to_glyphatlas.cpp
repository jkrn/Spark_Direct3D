#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <vector>
#include <windows.h>
#include <SDL.h>
#include <SDL_ttf.h>

using namespace std;

// --- Constants ---

const SDL_Color textColor = { 255, 255, 255, 255 };
const int glyphSpace = 5;
const uint16_t startChar = 0x0020;
const uint16_t endChar = 0x007E;
const int numtextChars = endChar - startChar + 1;
const int numSymbolChars = 6;
const int numGamepadChars = 19;
const int numAllChars = numtextChars + numSymbolChars + numGamepadChars;
const uint16_t symbolChars[numSymbolChars] = {
	0xE2D1 , // Mouse and Keyboard
	0xE2D2 , // Gamepad
	0xE2D3 , // Keyboard
	0xE2D4 ,  // Mouse
	0xE2D4 ,  // Mouse (Left Click)
	0xE2D4 ,  // Mouse (Right Click)
};
const uint16_t gamepadChars[numGamepadChars] = {
	0xEDE3 , // Start
	0xEECA , // Back
	0xF093 , // A
	0xF094 , // B
	0xF095 , // Y
	0xF096 , // X
	0xF108 , // Left Stick
	0xF109 , // Right Stick
	0xF10A , // LT
	0xF10B , // RT
	0xF10C , // LB
	0xF10D , // RB
	0xF10E , // Dpad Idle
	0xF10E , // Dpad Up
	0xF10E , // Dpad Left
	0xF10E , // Dpad Right
	0xF10E , // Dpad Down
	0xEDE3 , // Gem Icon (Placeholder)
	0xEDE3   // Checkpoint Icon (Placeholder)
};

// --- Global Variables ---

string g_text_ttf_name;
string g_symbol_ttf_name;
string g_gamepad_ttf_name;
string g_bmp_name;
string g_hpp_name;
int g_font_size = 0;
TTF_Font* g_text_font = NULL;
TTF_Font* g_symbol_font = NULL;
TTF_Font* g_gamepad_font = NULL;
int g_bmp_width = 0;
int g_bmp_height = 0;

// --- Glyph Atlas ---

class GlyphAtlas {
public:
	int glyphAtlasWidth;
	int glyphAtlasHeight;
	int offsetX[numAllChars];
	int advance[numAllChars];
	GlyphAtlas(TTF_Font* text_font, TTF_Font* symbol_font, TTF_Font* gamepad_font) {
		// Create vector of chars
		std::vector<uint16_t> charVec;
		for (uint16_t c = startChar; c <= endChar; c++) { charVec.push_back(c); }
		for (int i = 0; i < numSymbolChars; i++) { charVec.push_back(symbolChars[i]); }
		for (int i = 0; i < numGamepadChars; i++) { charVec.push_back(gamepadChars[i]); }
		// Glyph Atlas Size
		glyphAtlasWidth = 0;
		for (int i = 0; i < numAllChars; i++) {
			int adv = 0;
			uint16_t c = charVec.at(i);
			if(i < numtextChars) { TTF_GlyphMetrics(text_font, c, NULL, NULL, NULL, NULL, &adv); }
			else if(i < numtextChars + numSymbolChars) { TTF_GlyphMetrics(symbol_font, c, NULL, NULL, NULL, NULL, &adv); }
			else { TTF_GlyphMetrics(gamepad_font, c, NULL, NULL, NULL, NULL, &adv); }
			offsetX[i] = glyphAtlasWidth;
			advance[i] = adv;
			glyphAtlasWidth += (adv + glyphSpace);
		}
		glyphAtlasHeight = TTF_FontLineSkip(text_font);
		// Create Glyph Atlas
		SDL_Surface* surface = SDL_CreateRGBSurfaceWithFormat(0, glyphAtlasWidth, glyphAtlasHeight, 32, SDL_PIXELFORMAT_RGBA8888);
		SDL_FillRect(surface, NULL, SDL_MapRGBA(surface->format, 255, 255, 255, 0));
		for (int i = 0; i < numAllChars; i++) {
			uint16_t c = charVec.at(i);
			SDL_Surface* glyphSurface = NULL;
			int yOffset = 0;
			if (i < numtextChars) { glyphSurface = TTF_RenderGlyph_Blended(text_font, c, textColor); }
			else if (i < numtextChars + numSymbolChars) { glyphSurface = TTF_RenderGlyph_Blended(symbol_font, c, textColor); yOffset = 14; }
			else { glyphSurface = TTF_RenderGlyph_Blended(gamepad_font, c, textColor); }
			SDL_Rect srcRect = { 0, yOffset, glyphSurface->w, glyphSurface->h - yOffset };
			SDL_Rect dstRect = { offsetX[i], 0, glyphSurface->w, glyphSurface->h - yOffset };
			SDL_BlitSurface(glyphSurface, &srcRect, surface, &dstRect);
			SDL_FreeSurface(glyphSurface);
			glyphSurface = NULL;
		}
		// Save BMP
		g_bmp_width = surface->w;
		g_bmp_height = surface->h;
		SDL_SaveBMP(surface, g_bmp_name.c_str());
		SDL_FreeSurface(surface);
		surface = NULL;
	}
};

// --- SDL ---

bool initSDL() {
	if (SDL_Init(SDL_INIT_VIDEO) < 0) { return false; }
	if (!SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1")) { return false; }
	if (TTF_Init() == -1) { return false; }
	return true;
}

void closeSDL() {
	TTF_Quit();
	SDL_Quit();
}

// --- Font ---

bool loadFont() {
	g_text_font = TTF_OpenFontRW(SDL_RWFromFile(g_text_ttf_name.c_str(), "r"), 1, g_font_size);
	if (!g_text_font) { return false; }
	g_symbol_font = TTF_OpenFontRW(SDL_RWFromFile(g_symbol_ttf_name.c_str(), "r"), 1, g_font_size+10);
	if (!g_symbol_font) { return false; }
	g_gamepad_font = TTF_OpenFontRW(SDL_RWFromFile(g_gamepad_ttf_name.c_str(), "r"), 1, g_font_size);
	if (!g_gamepad_font) { return false; }
	return true;
}

void closeFont() {
	TTF_CloseFont(g_text_font);
	TTF_CloseFont(g_symbol_font);
	TTF_CloseFont(g_gamepad_font);
}

// --- HPP ---

void write_HPP_file(GlyphAtlas& glyphAtlas) {
	ofstream f(g_hpp_name);
	f << "#pragma once" << endl << endl;
	f << "const int atlasWidth = " << g_bmp_width << ";" << endl;
	f << "const int atlasHeight = " << g_bmp_height << ";" << endl;
	f << "const uint16_t startChar = 0x20;" << endl;
	f << "const uint16_t endChar = 0x7E;" << endl;
	f << "const int glyphSpace = 5;" << endl;
	f << "const int numtextChars = endChar - startChar + 1;" << endl;
	f << "const int numSymbolChars = 6;" << endl;
	f << "const int numGamepadChars = 19;" << endl;
	f << "const int numAllChars = numtextChars + numSymbolChars + numGamepadChars;" << endl;
	f << "const uint16_t symbol_Mouse_Keyboard_char = endChar + 0x01; // Mouse and Keyboard" << endl;
	f << "const uint16_t symbol_Gamepad_char = endChar + 0x02; // Gamepad" << endl;
	f << "const uint16_t symbol_Keyboard_char = endChar + 0x03; // Keyboard" << endl;
	f << "const uint16_t symbol_Mouse_char = endChar + 0x04; // Mouse" << endl;
	f << "const uint16_t symbol_Mouse_Left_char = endChar + 0x05; // Mouse (Left Click)" << endl;
	f << "const uint16_t symbol_Mouse_Right_char = endChar + 0x06; // Mouse (Right Click)" << endl;
	f << "const uint16_t gamepad_Start_char = endChar + 0x07; // Start" << endl;
	f << "const uint16_t gamepad_Back_char = endChar + 0x08; // Back" << endl;
	f << "const uint16_t gamepad_A_char = endChar + 0x09; // A" << endl;
	f << "const uint16_t gamepad_B_char = endChar + 0x0A; // B" << endl;
	f << "const uint16_t gamepad_Y_char = endChar + 0x0B; // Y" << endl;
	f << "const uint16_t gamepad_X_char = endChar + 0x0C; // X" << endl;
	f << "const uint16_t gamepad_LStick_char = endChar + 0x0D; // Left Stick" << endl;
	f << "const uint16_t gamepad_RStick_char = endChar + 0x0E; // Right Stick" << endl;
	f << "const uint16_t gamepad_LT_char = endChar + 0x0F; // LT" << endl;
	f << "const uint16_t gamepad_RT_char = endChar + 0x10; // RT" << endl;
	f << "const uint16_t gamepad_LB_char = endChar + 0x11; // LB" << endl;
	f << "const uint16_t gamepad_RB_char = endChar + 0x12; // RB" << endl;
	f << "const uint16_t gamepad_DPad_Idle_char = endChar + 0x13; // DPad Idle" << endl;
	f << "const uint16_t gamepad_DPad_Up_char = endChar + 0x14; // DPad Up" << endl;
	f << "const uint16_t gamepad_DPad_Left_char = endChar + 0x15; // Dpad Left" << endl;
	f << "const uint16_t gamepad_DPad_Right_char = endChar + 0x16; // Dpad Right" << endl;
	f << "const uint16_t gamepad_DPad_Down_char = endChar + 0x17; // Dpad Down" << endl;
	f << "const uint16_t gameicon_Gem_char = endChar + 0x18; // Gem" << endl;
	f << "const uint16_t gameicon_Checkpoint_char = endChar + 0x19; // Checkpoint" << endl;
	f << "const uint16_t atlasAdvance[] = { ";
	for (int i = 0; i < numAllChars; i++) {
		f << glyphAtlas.advance[i];
		if (i < numAllChars - 1) { f << ","; }
		else { f << " };" << endl; }
	}
	f << "const int atlasOffsetX[] = { ";
	for (int i = 0; i < numAllChars; i++) {
		f << glyphAtlas.offsetX[i];
		if (i < numAllChars - 1) { f << ","; }
		else{ f << " };"; }
	}
}

// --- Parameters ---

void printhelp() {
	cout << "Usage:" << endl;
	cout << "./convert_font_to_glyphatlas [PARAMETERS]" << endl;
	cout << "-help: prints this text" << endl;
	cout << "-tt [FILE NAME]: Text TTF File Name" << endl;
	cout << "-st [FILE NAME]: Symbol TTF File Name" << endl;
	cout << "-gt [FILE NAME]: Gamepad TTF File Name" << endl;
	cout << "-b [FILE NAME]: BMP File Name" << endl;
	cout << "-h [FILE NAME]: HPP File Name" << endl;
	cout << "-s [VALUE]: Font Size" << endl;
}

bool processInputParamters(int argc, char* argv[]) {
	bool ttMissing = true, stMissing = true, gtMissing = true, bMissing = true, hMissing = true, sMissing = true;
	string tt, st, gt, b, h, s;
	for (int currArg = 1; currArg < argc; currArg++) {
		string str(argv[currArg]);
		if (!str.compare("-help")) { printhelp(); return false; }
		else if (!str.compare("-tt")) { tt = string(argv[currArg + 1]); ttMissing = false; }
		else if (!str.compare("-st")) { st = string(argv[currArg + 1]); stMissing = false; }
		else if (!str.compare("-gt")) { gt = string(argv[currArg + 1]); gtMissing = false; }
		else if (!str.compare("-b")) { b = string(argv[currArg + 1]); bMissing = false; }
		else if (!str.compare("-h")) { h = string(argv[currArg + 1]); hMissing = false; }
		else if (!str.compare("-s")) { s = string(argv[currArg + 1]); sMissing = false; }
	}
	if (ttMissing || stMissing || gtMissing || bMissing || hMissing || sMissing) {
		if (ttMissing) { cout << "(!) Text TTF File Name Missing" << endl; }
		if (stMissing) { cout << "(!) Symbol TTF File Name Missing" << endl; }
		if (gtMissing) { cout << "(!) Gamepad TTF File Name Missing" << endl; }
		if (bMissing) { cout << "(!) BMP File Missing" << endl; }
		if (hMissing) { cout << "(!) HPP File Missing" << endl; }
		if (sMissing) { cout << "(!) Font Size Missing" << endl; }
		printhelp();
		return false;
	}
	g_text_ttf_name = tt;
	g_symbol_ttf_name = st;
	g_gamepad_ttf_name = gt;
	g_bmp_name = b;
	g_hpp_name = h;
	std::string::size_type sz;
	g_font_size = std::stoi(s,&sz);
	cout << "Text TTF File: " << g_text_ttf_name << endl;
	cout << "Symbol TTF File: " << g_symbol_ttf_name << endl;
	cout << "Gamepad TTF File: " << g_gamepad_ttf_name << endl;
	cout << "BMP File: " << g_bmp_name << endl;
	cout << "HPP File: " << g_hpp_name << endl;
	cout << "Font Size: " << g_font_size << endl;
	return true;
}

// --- Main ---

int main(int argc, char* argv[]) {
	if (!processInputParamters(argc, argv)) { return EXIT_FAILURE; }
	if (!initSDL()) { return EXIT_FAILURE; }
	if (!loadFont()) { return EXIT_FAILURE; }
	GlyphAtlas glyphAtlas(g_text_font, g_symbol_font, g_gamepad_font);
	write_HPP_file(glyphAtlas);
	closeFont();
	closeSDL();
	return EXIT_SUCCESS;
}